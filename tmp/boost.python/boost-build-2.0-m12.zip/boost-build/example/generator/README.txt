
This example shows how to declare a new generator class. It's necessary
when generator's logic is more complex that just running a single tool.

