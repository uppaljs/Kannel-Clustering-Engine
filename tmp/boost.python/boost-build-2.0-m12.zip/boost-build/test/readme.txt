Comprehensive tests for Boost.Build v2; requires Python. To test, execute:

    python test_all.py
