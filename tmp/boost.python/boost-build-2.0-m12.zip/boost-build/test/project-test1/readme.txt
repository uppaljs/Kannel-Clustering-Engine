Copyright 2003 Dave Abrahams 
Copyright 2002 Vladimir Prus 
Distributed under the Boost Software License, Version 1.0. 
(See accompanying file LICENSE_1_0.txt or http://www.boost.org/LICENSE_1_0.txt) 


This tests for basic project handling -- declaring subprojects, finding
parent projects and project roots and for working project-ids.
