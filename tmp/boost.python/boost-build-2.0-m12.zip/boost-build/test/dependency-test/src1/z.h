/* Copyright 2003, 2004, 2006 Vladimir Prus */
/* Distributed under the Boost Software License, Version 1.0. */
/* (See accompanying file LICENSE_1_0.txt or http://www.boost.org/LICENSE_1_0.txt) */

extern int dummy_variabled_need_to_suppress_empty_file_warning_on_hp_cxx_compiler;
